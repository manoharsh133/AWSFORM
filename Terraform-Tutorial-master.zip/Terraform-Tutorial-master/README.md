# Terraform-Tutorial

![](https://github.com/easyawslearn/Terraform-Tutorial/workflows/terraform-tutorials-ci/badge.svg)

Terraform Tutorial is the set of examples of [Terraform](https://www.terraform.io/) modules that is building the infrastructure resources 
on AWS Cloud.

To learn about module, follow the readme of each module.

## Developing

- **Terraform**: v0.11.14
- **Terraform Docs**: https://www.terraform.io/docs/configuration-0-11/index.html
- **Youtube Channel for subscription**: https://www.youtube.com/channel/UCck6BsJ0H8C8C8JVgSS1b8Q?view_as=subscriber
- **Terraform Tutorial in English**: https://www.youtube.com/watch?v=5WykrpB7qS4&list=PL_OdF9Z6GmVaRD6e6sYLQO_WYqTKcj3aj
- **Terraform Tutorial in Hindi**: https://www.youtube.com/watch?v=LNYQXLf60N4&list=PL_OdF9Z6GmVY9QfBfNUua_X2c2mT65SAX
